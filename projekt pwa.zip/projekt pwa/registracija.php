<!DOCTYPE html>
<html class="bg-light">
    <head>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title> Projektni zadatak Sirotković</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>

    <header>
         <h1 class="bg-danger header1" > Newsweek</h1>
        <nav class="navbar " >
            <a href="index.php">Home</a>
            <a  href="administrator.php">Admin</a>
            <a  href="kategorija.php?id=kult" >Kultura</a>
            <a   href="kategorija.php?id=sport" >Sport</a>
            <a   href="unos.html">Unos</a>
            
        </nav></header>
    <body class="container">
        <h2>Registracija</h2>
    <form action=""  method="POST"><br>
        Korisničko ime:  <br>
        <input type="text" id="username" name="username"> </input> <br><br>
        Ime:  <br>
        <input type="text" id="ime" name="ime"> </input><br><br>
        Prezime:  <br>
        <input type="text" id="prezime" name="prezime"> </input><br><br>
        Lozinka:  <br>
        <input type="password" id="pass" name="pass"> </input><br><br>
        <input type="submit" id="prijava" value="Registriraj se" >
</form>
<p>Imate račun? <a class="text-danger" href='administrator.php'> Login </a></p>
</body>
</html>

<?php

$dbc=mysqli_connect('localhost', 'root', '', 'projektpwa') or die ('Connection failed' . mysqli_connect_error());



$ime = $_POST['ime'];
$prezime = $_POST['prezime'];
$username = $_POST['username'];
$lozinka = $_POST['pass'];
$hashed_password = password_hash($lozinka, CRYPT_BLOWFISH);
$razina = 0;
$registriranKorisnik = '';


$sql = "SELECT korisnicko_ime FROM korisnik WHERE korisnicko_ime = ?";
$stmt = mysqli_stmt_init($dbc);
if (mysqli_stmt_prepare($stmt, $sql)) {
 mysqli_stmt_bind_param($stmt, 's', $username);
 mysqli_stmt_execute($stmt);
 mysqli_stmt_store_result($stmt);
 }
if(mysqli_stmt_num_rows($stmt) > 0){
 $msg='Korisničko ime već postoji!';
}else{
 $sql = "INSERT INTO korisnik (korisnicko_ime, ime, prezime, lozinka, 
razina)VALUES (?, ?, ?, ?, ?)";
 $stmt = mysqli_stmt_init($dbc);
 if (mysqli_stmt_prepare($stmt, $sql)) {
 mysqli_stmt_bind_param($stmt, 'ssssd', $username, $ime, $prezime, 
$hashed_password, $razina);
 mysqli_stmt_execute($stmt);
 $registriranKorisnik = true;
 }
}

if($registriranKorisnik == true) {
    echo '<h2>Korisnik je uspješno registriran!</h2>';
    }  



mysqli_close($dbc);

?>



