<!DOCTYPE html>
<html class="bg-light">
    <head>

    <style> </style>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title> Projektni zadatak Sirotković</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>

    <header>
         <h1 class="bg-danger header1" > Newsweek</h1>
        <nav class="navbar " >
            <a href="index.php">Home</a>
            <a  href="administrator.php">Admin</a>
            <a  href="kategorija.php?id=kult" >Kultura</a>
            <a   href="kategorija.php?id=sport" >Sport</a>
            <a   href="unos.html">Unos</a>
            
        </nav></header>
    <body class="container">
    <h2>Login</h2>

    <form id="login" name="login"  method="post"><br>
        Korisničko ime:  <br>
        <input type="text" id="username" name="username"> </input> <br><br>
        Lozinka:  <br>
        <input type="password" id="pass" name="pass"> </input><br><br>
        <input type="submit" name="prijava" value="Login" >
</form>
</body>
</html>



<?php
session_start();

$dbc=mysqli_connect('localhost', 'root', '', 'projektpwa') or die ('Connection failed' . mysqli_connect_error());
$levelKorisnika = 1;
if (isset($_POST['prijava'])) {
    $prijavaImeKorisnika = $_POST['username'];
    $prijavaLozinkaKorisnika = $_POST['pass'];
    $sql = "SELECT korisnicko_ime, lozinka, razina FROM korisnik WHERE korisnicko_ime = ?";
    $stmt = mysqli_stmt_init($dbc);
    if (mysqli_stmt_prepare($stmt, $sql)) {
    mysqli_stmt_bind_param($stmt, 's', $prijavaImeKorisnika);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);
    }
    mysqli_stmt_bind_result($stmt, $imeKorisnika, $lozinkaKorisnika, 
   $levelKorisnika);
    mysqli_stmt_fetch($stmt);

    if (password_verify($_POST['pass'], $lozinkaKorisnika) && 
mysqli_stmt_num_rows($stmt) > 0) {
 $uspjesnaPrijava = true;
 if($levelKorisnika == 1) {
    $admin = true;
    $dbc=mysqli_connect('localhost', 'root', '', 'projektpwa') or die ('Connection failed' . mysqli_connect_error());
    echo'<style> #login {display:none;} </style>';

$query = "SELECT * FROM clanak";
$result = mysqli_query($dbc, $query);
while($row = mysqli_fetch_array($result)) {
 
 echo  '
 
 <form enctype="multipart/form-data" action="" method="POST">
 <div class="form-item">
 <label for="title">Naslov vjesti:</label>
 <div class="form-field">
 <input type="text" name="title" class="form-field-textual" 
value="'.$row['naslov'].'">
 </div> 
 </div>
 <div class="form-item">
 <label for="about">Kratki sadržaj vijesti (do 50 
znakova):</label>
 <div class="form-field">
 <textarea name="about" id="" cols="30" rows="10" class="formfield-textual">'.$row['opis'].'</textarea>
 </div>
 </div>
 <div class="form-item">
 <label for="content">Sadržaj vijesti:</label>
 <div class="form-field">
 <textarea name="content" id="" cols="30" rows="10" class="formfield-textual">'.$row['vijest'].'</textarea>
 </div>
 </div>
 <div class="form-item">
 <label for="pphoto">Slika:</label>
 <div class="form-field">

 <input type="file" class="input-text" id="pphoto" 
value="'.$row['slika'].'" name="pphoto"/> <br><img src="' . $row ["slika"] .'" '. '" width=100px>
 </div> <br>
 </div>
 <div class="form-item">
 <label for="category">Kategorija vijesti:</label>
 <div class="form-field">
 <select name="category" id="" class="form-field-textual" 
value="'.$row['kategorija'].'">
 <option value="sport">Sport</option>
 <option value="kultura">Kultura</option>
 </select>
 </div>
 </div>
 <div class="form-item">
 <label>Spremiti u arhivu: 
 <div class="form-field">';
 if($row['arhiva'] == 0) {
 echo '<input type="checkbox" name="archive" id="archive"/> 
Arhiviraj?';
 } else {
 echo '<input type="checkbox" name="archive" id="archive" 
checked/> Arhiviraj?';
 }
 echo '</div>
 </label>
 </div>
 </div>
 <div class="form-item">
 <input type="hidden" name="id" class="form-field-textual" 
value="'.$row['id'].'">
 <button type="reset" value="Poništi">Poništi</button>
 <button type="submit" name="update" value="Prihvati"> 
Izmjeni</button>
 <button type="submit" name="delete" value="Izbriši"> 
Izbriši</button>
 </div>
 </form>';
}



  
    
    }
    else {
    $admin = false;
    
    }
    $_SESSION['$username'] = $imeKorisnika;
    $_SESSION['$razina'] = $levelKorisnika;
    } else {
    $uspjesnaPrijava = false;
    
    }
    
   }


   if (($uspjesnaPrijava == true && $admin == true) || (isset($_SESSION['$username'])) && $_SESSION['$razina'] == 1) {
    if(isset($_POST['delete'])){
        $id=$_POST['id'];
        $query = "DELETE FROM clanak WHERE id=$id ";
        $result = mysqli_query($dbc, $query);
       }
       if(isset($_POST['update'])){
    
        $category=$_POST['category'];
        $title=$_POST['title'];
        $image=$_POST['pphoto'];
        $about=$_POST['about'];
        $content=$_POST['content'];
        if(isset($_POST["archive"])) {
            $arhiva= 1 ;
        } else {
            $arhiva= 0 ;
        }
    
      
        $id=$_POST['id'];
        $query1 = "UPDATE clanak SET naslov='$title', opis='$about', vijest='$content', kategorija='$category', arhiva='$arhiva' WHERE id=$id ";
        $result1 = mysqli_query($dbc, $query1);
        }
 
 }
 else if ($uspjesnaPrijava == true && $admin == false) {
 
 echo '<p>Bok ' . $imeKorisnika . '! Uspješno ste prijavljeni, ali 
niste administrator.</p>';
 } else if (isset($_SESSION['$username']) && $_SESSION['$razina'] == 0) {
 
 echo '<p>Bok ' . $_SESSION['$username'] . '! Uspješno ste 
prijavljeni, ali niste administrator.</p>';
 } else if ($uspjesnaPrijava == false) {
 
 

 

 }
 

?>
