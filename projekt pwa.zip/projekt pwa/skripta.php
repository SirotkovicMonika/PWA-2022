<?php
$category=$_POST['category'];
$title=$_POST['title'];
$image=$_POST['pphoto'];
$about=$_POST['about'];
$content=$_POST['content'];
if(isset($_POST["archive"])) {
    $arhiva= 1 ;
} else {
    $arhiva= 0 ;
}
?>

<!DOCTYPE html>
<html  class="bg-light">
    <head>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title> Projektni zadatak Sirotković</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>

    <header>
         <h1 class="bg-danger header1" > Newsweek</h1>
        <nav class="navbar " >
        <a href="index.php">Home</a>
            <a  href="administrator.php">Admin</a>
            <a  href="kategorija.php?id=kult" >Kultura</a>
            <a   href="kategorija.php?id=sport" >Sport</a>
            <a   href="unos.html">Unos</a>
            
        </nav></header>
<body class="container">
    <section role="main" style="margin:0;">
        <div class="row">
        <h2 class="category" style="padding-left: 15px;"> <?php
        echo $category;
        ?></h2>
        <h4 class="title" style="margin-left: -40px;"><?php
        echo $title;
        ?></h4>
        
        </div>
        <section class="slika">
        <?php
        echo "<img src='$image'";
        ?>
        </section>
        <section class="about">
        <h3>
        <?php
        echo $about;
        ?>
        </h3>
        </section>
        <section class="sadrzaj">
        <p >
        <?php
       echo $content;
        ?>
        </p>
        </section>
        </section>

</body>


<?php
$category=$_POST['category'];
$title=$_POST['title'];
$image=$_POST['pphoto'];
$about=$_POST['about'];
$content=$_POST['content'];
if(isset($_POST["archive"])) {
    $arhiva= 1 ;
} else {
    $arhiva= 0 ;
}

$dbc=mysqli_connect('localhost', 'root', '', 'projektpwa') or die ('Connection failed' . mysqli_connect_error());
$query= "INSERT INTO clanak (kategorija, naslov, slika, opis, vijest, arhiva) VALUES('$category', '$title', '$image', '$about', '$content', '$arhiva')";
   
$result= mysqli_query($dbc, $query) or die('Error');

   ?>


<footer class="bg-secondary  text-light"> Monika Sirotković, msirotkov@tvz.hr - 2022 ©</footer>

</html>