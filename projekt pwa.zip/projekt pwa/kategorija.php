<!DOCTYPE html>
<html class="bg-light">
    <head>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta charset="UTF-8">
        <title> Projektni zadatak Sirotković</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>

    <header>
         <h1 class="bg-danger header1" > Newsweek</h1>
        <nav class="navbar " >
        <a href="index.php">Home</a>
            <a  href="administrator.php">Admin</a>
            <a  href="#kult" >Kultura</a>
            <a   href="kategorija.php?id=sport" >Sport</a>
            <a   href="unos.html">Unos</a>
            
        </nav></header>


   

        <body class=container>


        <?php
$dbc=mysqli_connect('localhost', 'root', '', 'projektpwa') or die ('Connection failed' . mysqli_connect_error());



$query = "SELECT * FROM clanak WHERE arhiva=1 AND kategorija='sport'";
$query1 = "SELECT * FROM clanak WHERE arhiva=1 AND kategorija='kultura'";

$result = mysqli_query($dbc, $query);
$result1 = mysqli_query($dbc, $query1);


if(mysqli_num_rows($result)) {
        echo '<h2 id="sport"> Sport </h2>';
        while ($row = mysqli_fetch_array($result)){
                echo '<br><h2>' . $row['naslov'] . '</h2>';
                echo '<h4>' . $row['opis'] . '</h4>';
                echo '<br> <img src="' . $row ["slika"] .'"<br> ';
                echo'<br><p>' .  $row['vijest'] . '</p> <br>'; }} 



                
if(mysqli_num_rows($result1)) {
        echo '<h2 id="kult"> Kultura </h2>';
        while ($row = mysqli_fetch_array($result1)){
                echo '<br><h2>' . $row['naslov'] . '</h2>';
                echo '<h4>' . $row['opis'] . '</h4>';
                echo '<br> <img src="' . $row ["slika"] .'"<br> ';
                echo'<br><p>' .  $row['vijest'] . '</p> <br>'; }}

?>






        </body>

  

<footer class="bg-secondary  text-light" > Monika Sirotković, msirotkov@tvz.hr - 2022 ©</footer>

</html>